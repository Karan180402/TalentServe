package com.web;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class UserServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database configuration
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/signup";
    private static final String JDBC_USERNAME = "root";
    private static final String JDBC_PASSWORD = "House309";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action != null) {
            if (action.equals("signin")) {
                signin(request, response);
            } else if (action.equals("login")) {
                login(request, response);
            } else if (action.equals("removeUser")) { // Add condition for remove action
                removeUser(request, response);
            } else if (action.equals("submitRequest")) { // Add condition for handling request submission
                submitRequest(request, response);
            }  else {
                // Handle other actions if needed
            }
        }
    }
    

    private void signin(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String email = request.getParameter("Email");
        String phone = request.getParameter("Phone_Number");
        String gender = request.getParameter("gender");

        // Insert user data into the database
        if (insertUser(username, password, email, phone, gender)) {
            response.sendRedirect("dashboard.jsp");
        } else {
            request.setAttribute("errorMessage", "Sign-up failed!");
            request.getRequestDispatcher("signup.jsp").forward(request, response);
        }
    }

    private void login(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Check user credentials in the database
        if (checkUser(username, password)) {
            // Create a session for the authenticated user
            HttpSession session = request.getSession();
            session.setAttribute("username", username);

            response.sendRedirect("dashboard.jsp");
        } else {
            request.setAttribute("errorMessage", "Login failed! Invalid username or password.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
    
    // Method to fetch user data
    private void removeUser(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String usernameToRemove = request.getParameter("usernameToRemove");

        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "DELETE FROM users WHERE user_id = ?")
        ) {
            preparedStatement.setString(1, usernameToRemove);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                response.sendRedirect("user_removed.jsp"); // Redirect to a success page
            } else {
                response.sendRedirect("remove_user_error.jsp"); // Redirect to an error page
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            response.sendRedirect("remove_user_error.jsp"); // Redirect to an error page
        }
    }

       

    private Connection getConnection() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);
    }

    private boolean insertUser(String username, String password, String email, String phone, String gender) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        boolean success = false;

        try {
            connection = getConnection();

            String sql = "INSERT INTO users (username, password, Email, Phone_Number, gender) VALUES (?, ?, ?, ?, ?)";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            preparedStatement.setString(3, email);
            preparedStatement.setString(4, phone);
            preparedStatement.setString(5, gender);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                success = true;
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(preparedStatement, connection);
        }
        return success;
    }

    private boolean checkUser(String username, String password) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        boolean success = false;

        try {
            connection = getConnection();

            String sql = "SELECT * FROM users WHERE username = ? AND password = ?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);

            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                success = true;
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(resultSet, preparedStatement, connection);
        }
        return success;
    }
    private void submitRequest(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String requestType = request.getParameter("requestType");
        String requestDescription = request.getParameter("requestDescription");

        // Retrieve the username from the session
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");

        // Insert request into the database
        if (username != null && insertRequest(requestType, requestDescription, username)) {
            // Redirect to a success page
            response.sendRedirect("request_success.jsp");
        } else {
            // Redirect to an error page if insertion fails
            response.sendRedirect("request_error.jsp");
        }
    }

    private boolean insertRequest(String requestType, String requestDescription, String username) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        boolean success = false;

        try {
            // Get the user_id based on the username
            int userId = getUserIdByUsername(username);
            if (userId == -1) {
                // User not found, return false or handle accordingly
                return false;
            }

            // Get connection to the database
            connection = getConnection();

            // Prepare the SQL statement to insert the request
            String sql = "INSERT INTO requests (request_type, description, user_id) VALUES (?, ?, ?)";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, requestType);
            preparedStatement.setString(2, requestDescription);
            preparedStatement.setInt(3, userId); // Set the user_id

            // Execute the SQL statement
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                success = true;
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources
            closeResources(preparedStatement, connection);
        }
        return success;
    }
    private int getUserIdByUsername(String username) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        int userId = -1; // Default value if user is not found

        try {
            // Get connection to the database
            connection = getConnection();

            // Prepare the SQL statement to retrieve user_id based on username
            String sql = "SELECT user_id FROM users WHERE username = ?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, username);

            // Execute the SQL statement
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                userId = resultSet.getInt("user_id");
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources
            closeResources(resultSet, preparedStatement, connection);
        }

        return userId;
    }
    


   

    


    private void closeResources(ResultSet rs, PreparedStatement ps, Connection conn) {
        try {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void closeResources(PreparedStatement ps, Connection conn) {
        try {
            if (ps != null) ps.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

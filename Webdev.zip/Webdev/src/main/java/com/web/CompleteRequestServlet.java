package com.web;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/completeRequest")
public class CompleteRequestServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve request parameter (requestId)
        int requestId = Integer.parseInt(request.getParameter("requestId"));
        
        // Retrieve resolved description parameter
        String resolvedDescription = request.getParameter("description");

        // Update request status in the database
        boolean success = updateRequestStatus(requestId, resolvedDescription);

        // Send response indicating success or failure
        response.setContentType("text/plain");
        if (success) {
            response.getWriter().write("Request completed successfully.");
        } else {
            response.getWriter().write("Failed to complete request.");
        }
    }


    private boolean updateRequestStatus(int requestId, String resolvedDescription) {
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement("UPDATE requests SET status = 'Complete', resolved_description = ? WHERE request_id = ?")) {
            preparedStatement.setString(1, resolvedDescription);
            preparedStatement.setInt(2, requestId);
            int rowsUpdated = preparedStatement.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }


    // Establishes a database connection
    private Connection getConnection() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        String JDBC_URL = "jdbc:mysql://localhost:3306/signup";
        String JDBC_USERNAME = "root";
        String JDBC_PASSWORD = "House309";
        return DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);
    }
}

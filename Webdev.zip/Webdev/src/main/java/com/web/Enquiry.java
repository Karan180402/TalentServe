package com.web;

public class Enquiry {
    private int enquiryId;
    private String name;
    private String email;
    private String requestType;
    private String description;
    private String preferredTime;
    private String status;

    private static final String STATUS_PENDING = "Pending";
    private static final String STATUS_IN_PROGRESS = "In Progress";
    private static final String STATUS_COMPLETED = "Completed";

    // Constructor
    public Enquiry(int enquiryId, String name, String email, String requestType, String description, String preferredTime, String status) {
        this.enquiryId = enquiryId;
        this.name = name;
        this.email = email;
        this.requestType = requestType;
        this.description = description;
        this.preferredTime = preferredTime;
        this.status = status;
    }

    // Getters and setters
    public int getEnquiryId() {
        return enquiryId;
    }

    public void setEnquiryId(int enquiryId) {
        this.enquiryId = enquiryId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPreferredTime() {
        return preferredTime;
    }

    public void setPreferredTime(String preferredTime) {
        this.preferredTime = preferredTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public static String getStatusPending() {
        return STATUS_PENDING;
    }

    public static String getStatusInProgress() {
        return STATUS_IN_PROGRESS;
    }

    public static String getStatusCompleted() {
        return STATUS_COMPLETED;
    }
}

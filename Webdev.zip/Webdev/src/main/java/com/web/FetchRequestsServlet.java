package com.web;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

@WebServlet("/fetchRequests")
public class FetchRequestsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database configuration
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/signup";
    private static final String JDBC_USERNAME = "root";
    private static final String JDBC_PASSWORD = "House309";

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String requestType = request.getParameter("type");
        List<Request> requests = null;
        if (requestType == null || requestType.isEmpty()) {
            // Fetch all requests
            requests = getRequests(null); // Pass null to fetch all requests
        } else {
            // Fetch requests of the specified type
            requests = getRequests(requestType);
        }
        // Convert requests to JSON and send response
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(new Gson().toJson(requests));
    }

    private List<Request> getRequests(String type) {
        List<Request> requests = new ArrayList<>();
        String sql = "SELECT * FROM requests";
        if (type != null) {
            sql += " WHERE request_type = ?";
        }
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            if (type != null) {
                preparedStatement.setString(1, type);
            }
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                int requestId = rs.getInt("request_id");
                String requestType = rs.getString("request_type");
                String requestDescription = rs.getString("description");
                String requestStatus = rs.getString("status");
                Timestamp timestamp = rs.getTimestamp("timestamp");
                int userId = rs.getInt("user_id"); // Get user ID
                String resolvedDescription = rs.getString("resolved_description");
                requests.add(new Request(requestId, userId, requestType, requestDescription, requestStatus, timestamp, resolvedDescription));
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return requests;
    }

    private Connection getConnection() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);
    }
}

package com.web;

public class UserData {
    private String username;
    private String email;
    private String phoneNumber;
    private String gender;

    // Constructor, getters, and setters
    public UserData(String username, String email, String phoneNumber, String gender) {
        this.username = username;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.gender = gender;
    }

    public String getusername() {
        return username;
    }

    public void setusername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone_Number() {
        return phoneNumber;
    }

    public void setPhone_Number(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getgender() {
        return gender;
    }

    public void setgender(String gender) {
        this.gender = gender;
    }
}


package com.web;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/updateStatus")
public class UpdateStatusServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int enquiryId = Integer.parseInt(request.getParameter("enquiryId"));
        String newStatus = request.getParameter("newStatus");
        
        // Call a method to update the status in the database
        boolean success = updateEnquiryStatus(enquiryId, newStatus);
        
        // Respond with appropriate message
        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(success ? "Status updated successfully!" : "Failed to update status!");
    }

    // Method to update status in the database
    private boolean updateEnquiryStatus(int enquiryId, String newStatus) {
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement("UPDATE enquiries SET status = ? WHERE enquiry_id = ?")) {
            statement.setString(1, newStatus);
            statement.setInt(2, enquiryId);
            int rowsUpdated = statement.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to establish database connection
    private Connection getConnection() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/signup", "root", "House309");
    }
}

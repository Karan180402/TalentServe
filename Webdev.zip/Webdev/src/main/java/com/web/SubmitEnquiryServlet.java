package com.web;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/submitEnquiry")
public class SubmitEnquiryServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form data
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String requestType = request.getParameter("requestType");
        String description = request.getParameter("description");
        String preferredTime = request.getParameter("preferredTime");
        String status = "Pending"; // Set status to pending for new enquiries

        // Insert enquiry into the database
        if (insertEnquiry(name, email, requestType, description, preferredTime, status)) {
            // Send success response to client
            response.setContentType("text/plain");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write("Enquiry successfully submitted!"); // Send success message
        } else {
            // Send error response to client
            response.setContentType("text/plain");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write("Failed to submit enquiry!"); // Send error message
        }
    }

    // Method to insert enquiry into the database
    private boolean insertEnquiry(String name, String email, String requestType, String description, String preferredTime, String status) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Establish database connection
            connection = getConnection();

            // Prepare SQL statement for insertion
            String sql = "INSERT INTO enquiries (name, email, request_type, description, preferred_time, status) VALUES (?, ?, ?, ?, ?, ?)";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3, requestType);
            preparedStatement.setString(4, description);
            preparedStatement.setString(5, preferredTime);
            preparedStatement.setString(6, status);

            // Execute the insertion statement
            int rowsInserted = preparedStatement.executeUpdate();
            return rowsInserted > 0;
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return false;
        } finally {
            // Close resources
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    // Method to establish database connection
    private Connection getConnection() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/signup", "root", "House309");
    }
}

package com.web;

import java.sql.Timestamp;

public class Request {
    private int requestId;
    private int userId; // New attribute
    private String requestType;
    private String requestDescription;
    private String status;
    private Timestamp timestamp;
    private String resolvedDescription;

    // Constructor
    public Request(int requestId, int userId, String requestType, String requestDescription, String status, Timestamp timestamp, String resolvedDescription) {
        this.requestId = requestId;
        this.userId = userId;
        this.requestType = requestType;
        this.requestDescription = requestDescription;
        this.status = status;
        this.timestamp = timestamp;
        this.resolvedDescription = resolvedDescription;
    }

    // Getters and setters
    public int getRequestId() {
        return requestId;
    }

    public void setRequestId(int requestId) {
        this.requestId = requestId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public String getRequestDescription() {
        return requestDescription;
    }

    public void setRequestDescription(String requestDescription) {
        this.requestDescription = requestDescription;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }

    public String getResolvedDescription() {
        return resolvedDescription;
    }

    public void setResolvedDescription(String resolvedDescription) {
        this.resolvedDescription = resolvedDescription;
    }
}
